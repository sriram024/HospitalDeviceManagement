import { Injectable } from '@angular/core';
import { Employee } from './employee';

// import { Injectable } from '@angular/core';
import { HttpClient } from'@angular/common/http';
import { User } from'./user'; 
import { Observable } from'rxjs'; 
import { Message } from'./message'; 
import {HttpClientModule } from'@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class EmpserviceService {

  private baseUrl: string = 'http://localhost:8001/Employee';
  constructor(private http: HttpClient) {}
 

  listAllRecords(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.baseUrl}/list`);
  }
  deleteById(id: number): Observable<Message> {
    return this.http.delete<Message>(`${this.baseUrl}/delete/${id}`);
  }
  addEmployee(employee: Employee): Observable<Message> {
    return this.http.post<Message>(`${this.baseUrl}/add`, employee);
  }
  getEmployeeById(id: number): Observable<Employee> {
    return this.http.get<Employee>(`${this.baseUrl}/view/${id}`);
  }
  updateEmployee(employee: Employee): Observable<Message> {
    return this.http.put<Message>(`${this.baseUrl}/update`, employee);
  }
}