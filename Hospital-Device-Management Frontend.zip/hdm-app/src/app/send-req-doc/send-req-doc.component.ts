import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
import { Docreq } from '../docreq';
import { Message } from '../message';
import { Requestdevice } from '../requestdevice';
import { RequestserviceService } from '../requestservice.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-send-req-doc',
  templateUrl: './send-req-doc.component.html',
  styleUrls: ['./send-req-doc.component.css']
})
export class SendReqDocComponent implements OnInit {

  doctor: Requestdevice = new Requestdevice();
  message: Message = new Message();
  uname:number=0;
  did:number=0;
  constructor(private service: RequestserviceService, private router: Router,private route: ActivatedRoute) {}

  ngOnInit(): void {
     this.uname = JSON.parse(sessionStorage.getItem('username') || '{}');
    // let uname=sessionStorage.getItem('uname');
    this.route.params.subscribe(
      (params: Params) => {
        console.log(params['did']);
        this.did=params['did']
      }
    );

    this.doctor = new Requestdevice();
    this.doctor.dname = this.did;
    this.doctor.dename = this.uname;
    this.doctor.statusss="pending";
  }

  createDoctor() {
    this.service.addFinance(this.doctor).subscribe((data) => {
      console.log(this.doctor.dename);
      this.message = data;
      alert("Send Successfully")
      this.router.navigate(['viewdevdoc']);
    });
    this.doctor = new Requestdevice();
  }
}
