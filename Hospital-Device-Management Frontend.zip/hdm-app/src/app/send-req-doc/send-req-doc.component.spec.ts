import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SendReqDocComponent } from './send-req-doc.component';

describe('SendReqDocComponent', () => {
  let component: SendReqDocComponent;
  let fixture: ComponentFixture<SendReqDocComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SendReqDocComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SendReqDocComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
