import { Injectable } from '@angular/core';
import { HttpClient } from'@angular/common/http';
import { User } from'./user'; 
import { Observable } from'rxjs'; 
import { Message } from'./message'; 
import {HttpClientModule } from'@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

 
private baseUrl : string = 'http://localhost:8001/admin'; 
private baseUrl2 : string = 'http://localhost:8001/Employee'; 
private baseUrl3 : string = 'http://localhost:8001/doctor'; 
private baseUrl4 : string = 'http://localhost:8001/finance'; 

constructor(private http:HttpClient) { } 


createStudent(user:User):Observable<Message>{ 
return this.http.post<Message>(`${this.baseUrl2}/save`,user); 
  }  
createDoctor(user:User):Observable<Message>{ 
  return this.http.post<Message>(`${this.baseUrl3}/savedoctor`,user); 
    } 
createFinance(user:User):Observable<Message>{ 
  return this.http.post<Message>(`${this.baseUrl4}/savefinance`,user); 
    }       
createAdmin(user:User):Observable<Message>{ 
  return this.http.post<Message>(`${this.baseUrl}/saveadmin`,user); 
    } 
}