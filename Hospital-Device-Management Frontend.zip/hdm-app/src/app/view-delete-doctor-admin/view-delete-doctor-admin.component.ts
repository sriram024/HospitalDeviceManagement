import { Component, OnInit } from '@angular/core';
import { DocservicsService } from '../docservics.service';
import { Router } from '@angular/router';
import { Doctor } from '../doctor';
import { Message } from '../message'; 

@Component({
  selector: 'app-view-delete-doctor-admin',
  templateUrl: './view-delete-doctor-admin.component.html',
  styleUrls: ['./view-delete-doctor-admin.component.css'],
})
export class ViewDeleteDoctorAdminComponent implements OnInit {
  doctor: Doctor[] = [];
  message: Message = new Message();

  constructor(private service: DocservicsService, private router: Router) {}

  ngOnInit(): void {
    this.getAllDoctor();
  }
  getAllDoctor() {
    this.service.getAllDoctor().subscribe(
      (data) => {
        this.doctor = data;
      },
      (error) => {
        this.doctor = [];
      }
    );
  }
  deleteDoctor(id: number) {
    this.service.deleteOneDoctor(id).subscribe(
      (data) => {
        (this.message = data), this.getAllDoctor();
      },
      (error) => {
        console.log(error);
      }
    );
  }
  editDoctor(id: number) {
    this.router.navigate(['edit', id]);
  }
}
