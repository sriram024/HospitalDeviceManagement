export class Finance {
    fid: number = 0;
    fname: string = ' ';
  email: string = '';
  exp: number = 0;
  password:string='';

}
