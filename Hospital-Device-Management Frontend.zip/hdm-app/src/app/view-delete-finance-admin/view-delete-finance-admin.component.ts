import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Finance } from '../finance';
import { FinanceserviceService } from '../financeservice.service';
import { Message } from '../message';

@Component({
  selector: 'app-view-delete-finance-admin',
  templateUrl: './view-delete-finance-admin.component.html',
  styleUrls: ['./view-delete-finance-admin.component.css']
})
export class ViewDeleteFinanceAdminComponent implements OnInit {
  doctor: Finance[] = [];
  message: Message = new Message();

  constructor(private service: FinanceserviceService, private router: Router) {}

  ngOnInit(): void {
    this.listAllRecords();
  }
  listAllRecords() {
    this.service.listAllRecords().subscribe(
      (data) => {
        this.doctor = data;
      },
      (error) => {
        this.doctor = [];
      }
    );
  }
  deleteById(id: number) {
    this.service.deleteOneFinance(id).subscribe(
      (data) => {
        (this.message = data), this.listAllRecords();
      },
      (error) => {
        console.log(error);
      }
    );
  }
  // editDoctor(id: number) {
  //   this.router.navigate(['edit', id]);
  // }
}
