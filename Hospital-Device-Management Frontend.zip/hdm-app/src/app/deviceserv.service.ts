import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Device } from './device';
import { Message } from './message';

@Injectable({
  providedIn: 'root'
})
export class DeviceservService {

  private baseUrl: string = 'http://localhost:8001/Device';
  constructor(private http: HttpClient) {}

  getAlldevice(): Observable<Device[]> {
    return this.http.get<Device[]>(`${this.baseUrl}/all`);
  }
  deleteOneDoctor(id: number): Observable<Message> {
    return this.http.delete<Message>(`${this.baseUrl}/remove/${id}`);
  }
  createDoctor(doctor: Device): Observable<Message> {
    return this.http.post<Message>(`${this.baseUrl}/save`, doctor);
  }
  getOneDoctor(id: number): Observable<Device> {
    return this.http.get<Device>(`${this.baseUrl}/one/${id}`);
  }
  getDeviceById(id: number): Observable<Device> {
    return this.http.get<Device>(`${this.baseUrl}/one/${id}`);
  }
  updateDoctor(doctor: Device): Observable<Message> {
    return this.http.put<Message>(`${this.baseUrl}/update`, doctor);
  }
}

