import { TestBed } from '@angular/core/testing';

import { SendreqdocService } from './sendreqdoc.service';

describe('SendreqdocService', () => {
  let service: SendreqdocService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SendreqdocService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
