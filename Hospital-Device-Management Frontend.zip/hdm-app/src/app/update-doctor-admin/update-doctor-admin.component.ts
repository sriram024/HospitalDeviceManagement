import { Component, OnInit } from '@angular/core';
import { DocservicsService } from '../docservics.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Doctor } from '../doctor';
@Component({
  selector: 'app-update-doctor-admin',
  templateUrl: './update-doctor-admin.component.html',
  styleUrls: ['./update-doctor-admin.component.css'],
})
export class UpdateDoctorAdminComponent implements OnInit {
  doctor: Doctor = new Doctor();
  id: number = 0;

  constructor(
    private service: DocservicsService,
    private activeRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.doctor = new Doctor();
    this.id = this.activeRouter.snapshot.params['id'];
    this.service.getOneDoctor(this.id).subscribe((data) => {
      this.doctor = data;
    });
  }
  updateDoctor() {
    this.service.updateDoctor(this.doctor).subscribe((data) => {
      console.log(data), this.router.navigate(['all']);
    });
  }
}
