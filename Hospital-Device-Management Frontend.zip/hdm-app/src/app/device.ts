export class Device {
    did:number=0;
    dname:string="";
    ddesc:string="";
    
}
