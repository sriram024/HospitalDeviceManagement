import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmpserviceService } from '../empservice.service';

@Component({
  selector: 'app-employee-home',
  templateUrl: './employee-home.component.html',
  styleUrls: ['./employee-home.component.css']
})
export class EmployeeHomeComponent implements OnInit {

  employee: Employee = new Employee();
  id: number = 0;
  lid:number=0;
  constructor(
    private service: EmpserviceService,
    private activeRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
  }

  onclick(){
      this.router.navigate(['empprofile']);
  }
  onclick2(){
    this.router.navigate(['viewdev']);
}
onclick3(){
  sessionStorage.removeItem('username');
  this.router.navigate(['front']);
  
}

}
