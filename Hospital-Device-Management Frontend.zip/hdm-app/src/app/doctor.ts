export class Doctor {
    id: number = 0;
    name: string = '';
    qualification: string = '';
    email: string = '';
    gender: string = '';
    password:string='';
}
