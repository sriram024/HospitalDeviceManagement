import { Component, OnInit } from '@angular/core';
import { DocservicsService } from '../docservics.service';
import { Router } from '@angular/router';
import { Doctor } from '../doctor';
import { Message } from '../message';  

@Component({
  selector: 'app-add-doctor-admin',
  templateUrl: './add-doctor-admin.component.html',
  styleUrls: ['./add-doctor-admin.component.css'],
})
export class AddDoctorAdminComponent implements OnInit {
  doctor: Doctor = new Doctor();
  message: Message = new Message();
  constructor(private service: DocservicsService, private router: Router) {}

  ngOnInit(): void {}

  createDoctor() {
    this.service.createDoctor(this.doctor).subscribe((data) => {
      this.message = data;
      console.log(this.doctor)
    });
    this.doctor = new Doctor();
  }
}
