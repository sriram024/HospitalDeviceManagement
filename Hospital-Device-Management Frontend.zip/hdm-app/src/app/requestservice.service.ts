import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Requestdevice } from './requestdevice';
import { Message } from './message';
// import { Docreq } from './docreq';

@Injectable({
  providedIn: 'root',
})
export class RequestserviceService {
  private baseUrl: string = 'http://localhost:8001/request';
  constructor(private http: HttpClient) {}

  listAllRecords(): Observable<Requestdevice[]> {
    return this.http.get<Requestdevice[]>(`${this.baseUrl}/listrequest`);
  }
  deleteById(id: number): Observable<Message> {
    return this.http.delete<Message>(`${this.baseUrl}/remove/${id}`);
  }
  addFinance(finance: Requestdevice): Observable<Message> {
    return this.http.post<Message>(`${this.baseUrl}/requestadd`, finance);
  }
  getEmployeeById(id: number): Observable<Requestdevice> {
    return this.http.get<Requestdevice>(`${this.baseUrl}/viewrequest/${id}`);
  }
  updateFinance(employee: Requestdevice): Observable<Message> {
    return this.http.put<Message>(`${this.baseUrl}/updaterequest`, employee);
  }
  getFinanceID(id: number): Observable<Requestdevice> {
    return this.http.get<Requestdevice>(`${this.baseUrl}/sr/code?code2=${id}`);
  }
}
