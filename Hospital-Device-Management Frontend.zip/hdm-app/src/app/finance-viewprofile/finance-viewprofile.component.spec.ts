import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceViewprofileComponent } from './finance-viewprofile.component';

describe('FinanceViewprofileComponent', () => {
  let component: FinanceViewprofileComponent;
  let fixture: ComponentFixture<FinanceViewprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinanceViewprofileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceViewprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
