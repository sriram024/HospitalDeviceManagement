import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Finance } from '../finance';
import { FinanceserviceService } from '../financeservice.service';
// import { FinanceserviceService } from './f';
import { Message } from '../message';


@Component({
  selector: 'app-finance-viewprofile',
  templateUrl: './finance-viewprofile.component.html',
  styleUrls: ['./finance-viewprofile.component.css']
})
export class FinanceViewprofileComponent implements OnInit {

  finance: Finance = new Finance();
  id: number = 0;
  lid:number=0;
  message: Message = new Message();
  constructor(
    private service: FinanceserviceService,
    private activeRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
     this.lid = JSON.parse(sessionStorage.getItem('username') || '{}');
    this.finance = new Finance();
    this.service.getFinanceById(this.lid).subscribe((data) => {
      this.router.navigate(['finrpfilr']);
      this.finance = data;
    });
  }
  addEmployee(){
    this.service.updateFinance(this.finance).subscribe((data) => {
      console.log(data), this.router.navigate(['finhome']);
    });
  }
}
