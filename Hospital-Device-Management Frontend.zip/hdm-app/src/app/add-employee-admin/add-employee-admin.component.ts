import { Component, OnInit } from '@angular/core';
import { EmpserviceService } from '../empservice.service';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { Message } from '../message';  

@Component({
  selector: 'app-add-employee-admin',
  templateUrl: './add-employee-admin.component.html',
  styleUrls: ['./add-employee-admin.component.css'],
})
export class AddEmployeeAdminComponent implements OnInit {
  employee: Employee = new Employee();
  message: Message = new Message();
  constructor(private service: EmpserviceService, private router: Router) {}

  ngOnInit(): void {}

  addEmployee() {
    this.service.addEmployee(this.employee).subscribe((data) => {
      this.message = data;
      console.log(this.employee);
    });
    this.employee = new Employee();
  }
}
