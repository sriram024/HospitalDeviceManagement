import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceDeviceeditComponent } from './finance-deviceedit.component';

describe('FinanceDeviceeditComponent', () => {
  let component: FinanceDeviceeditComponent;
  let fixture: ComponentFixture<FinanceDeviceeditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinanceDeviceeditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceDeviceeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
