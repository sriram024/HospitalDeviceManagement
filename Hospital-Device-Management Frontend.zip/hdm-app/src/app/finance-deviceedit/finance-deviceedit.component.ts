import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Device } from '../device';
import { DeviceservService } from '../deviceserv.service';

@Component({
  selector: 'app-finance-deviceedit',
  templateUrl: './finance-deviceedit.component.html',
  styleUrls: ['./finance-deviceedit.component.css']
})
export class FinanceDeviceeditComponent implements OnInit {

  employee: Device = new Device();
  id: number = 0;

  constructor(
    private service: DeviceservService,
    private activeRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.employee = new Device();
    this.id = this.activeRouter.snapshot.params['id'];
    this.service.getOneDoctor(this.id).subscribe((data) => {
      this.employee = data;
    });
  }
  updateEmployee() {
    this.service.updateDoctor(this.employee).subscribe((data) => {
      console.log(data), this.router.navigate(['viewdevice']);
    });
  }

}
