import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';

// import { AppRoutingModule } from './app-routing.module';
// import { AppComponent } from './app.component';
import { AddDoctorAdminComponent } from './add-doctor-admin/add-doctor-admin.component';
import { ViewDeleteDoctorAdminComponent } from './view-delete-doctor-admin/view-delete-doctor-admin.component';
import { AddEmployeeAdminComponent } from './add-employee-admin/add-employee-admin.component';
import { ViewDeleteEmployeeAdminComponent } from './view-delete-employee-admin/view-delete-employee-admin.component';
import { UpdateEmployeeAdminComponent } from './update-employee-admin/update-employee-admin.component';
import { AddFinanceAdminComponent } from './add-finance-admin/add-finance-admin.component';
import { ViewDeleteFinanceAdminComponent } from './view-delete-finance-admin/view-delete-finance-admin.component';
import { UpdateFinanceAdminComponent } from './update-finance-admin/update-finance-admin.component';
import { RequestComponent } from './request/request.component';
import { DeviceComponent } from './device/device.component';
// import { LoginComponent } from './login/login.component';

import { AdminHomeComponent } from './admin-home/admin-home.component';
import { UpdateDoctorAdminComponent } from './update-doctor-admin/update-doctor-admin.component';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { EmployeeHomeComponent } from './employee-home/employee-home.component';
import { EmployeeViewprofileComponent } from './employee-viewprofile/employee-viewprofile.component';
import { EmployeeUpdateprofileComponent } from './employee-updateprofile/employee-updateprofile.component';
import { EmployeeViewdeviceComponent } from './employee-viewdevice/employee-viewdevice.component';
import { DoctorProfileComponent } from './doctor-profile/doctor-profile.component';
import { DoctorViewprofileComponent } from './doctor-viewprofile/doctor-viewprofile.component';
import { DoctorViewdeviceComponent } from './doctor-viewdevice/doctor-viewdevice.component';
import { DoctorSendrequestComponent } from './doctor-sendrequest/doctor-sendrequest.component';
import { RequesAdminComponent } from './reques-admin/reques-admin.component';
import { FinanceHomeComponent } from './finance-home/finance-home.component';
import { FinanceViewprofileComponent } from './finance-viewprofile/finance-viewprofile.component';
import { FinanceViewdeviceComponent } from './finance-viewdevice/finance-viewdevice.component';
import { FinanceApproverejectreqComponent } from './finance-approverejectreq/finance-approverejectreq.component';
import { FinanceDeviceaddComponent } from './finance-deviceadd/finance-deviceadd.component';
import { FinanceDeviceeditComponent } from './finance-deviceedit/finance-deviceedit.component';
import { SendReqDocComponent } from './send-req-doc/send-req-doc.component';
import { UpdateStatusAdminComponent } from './update-status-admin/update-status-admin.component';
import { FinanceUpdateRequestComponent } from './finance-update-request/finance-update-request.component';



@NgModule({
  declarations: [
    AppComponent,
    AddDoctorAdminComponent,
    ViewDeleteDoctorAdminComponent,
    
    AddEmployeeAdminComponent,
    ViewDeleteEmployeeAdminComponent,
    UpdateEmployeeAdminComponent,
    AddFinanceAdminComponent,
    ViewDeleteFinanceAdminComponent,
    UpdateFinanceAdminComponent,
    RequestComponent,
    DeviceComponent,
    LoginComponent,
    AdminHomeComponent,
    UpdateDoctorAdminComponent,
    FrontpageComponent,
    AboutusComponent,
    ContactusComponent,
    EmployeeHomeComponent,
    EmployeeViewprofileComponent,
    EmployeeUpdateprofileComponent,
    EmployeeViewdeviceComponent,
    DoctorProfileComponent,
    DoctorViewprofileComponent,
    DoctorViewdeviceComponent,
    DoctorSendrequestComponent,
    RequesAdminComponent,
    FinanceHomeComponent,
    FinanceViewprofileComponent,
    FinanceDeviceaddComponent,
    FinanceViewdeviceComponent,
    FinanceApproverejectreqComponent,
    FinanceViewdeviceComponent,
    FinanceDeviceeditComponent,
    SendReqDocComponent,
    UpdateStatusAdminComponent,
    FinanceUpdateRequestComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
