import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message'; 
import { Adminre } from '../adminre';
import { RequestserviceService } from '../requestservice.service';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {
  we: Adminre[] = [];
  message: Message = new Message();
  constructor(private service: RequestserviceService, private router: Router){}

  ngOnInit(): void {
    this.listAllRecord();
  }
  listAllRecord() {
    this.service.listAllRecords().subscribe(
      (data) => {
        //  this.we = data;
      },
      (error) => {
        this.we = [];
      }
    );
  }

  // deleteEmployee(id: number) {
  //   // this.service.deleteById(id).subscribe(
  //     (data) => {
  //       (this.message = data)
  //     },
  //     (error) => {
  //       console.log(error);
  //     }
  //   );

}
