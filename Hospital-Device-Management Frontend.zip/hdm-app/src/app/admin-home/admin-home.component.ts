import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css'],
})
export class AdminHomeComponent {
  selectedDay: string = '';
  selectedEmp: string = '';
  selectedFin: string = '';
  selectedReq:string='';
  constructor(private router: Router) {}
  //event handler for the select element's change event
  selectChangeHandler(event: any) {
    //update the ui
    var i = document.getElementById('emp');
    var j = document.getElementById('doc');
    var k = document.getElementById('fin');
    var r = document.getElementById('Request');

    if (event.target == i) {
      console.log(event.target);
      this.selectedEmp = event.target.value;
      if (this.selectedEmp == 'Add') {
        this.router.navigate(['add-emp']);
        console.log(this.selectedEmp);
      }
      if (this.selectedEmp == 'view') {
        this.router.navigate(['view-emp']);
      }
    }
    // this.selectedEmp = i.selectedIndex;
    if (event.target == j) {
      this.selectedDay = event.target.value;
      if (this.selectedDay == 'Add') {
        this.router.navigate(['add-doc']);
      }
      if (this.selectedDay == 'view') {
        this.router.navigate(['view-doc']);
      }
    }
if (event.target == k) {
      this.selectedFin = event.target.value;
      if (this.selectedFin == 'Add') {
        this.router.navigate(['add-fin']);
      }
      if (this.selectedFin == 'view') {
        this.router.navigate(['view-fin']);

      }}

}

onClick(){
  this.router.navigate(['req']);
}
onclick3(){
  sessionStorage.removeItem('username');
  this.router.navigate(['front']);
  
}

onClick1() {
  this.router.navigate(['dev']);
}
}