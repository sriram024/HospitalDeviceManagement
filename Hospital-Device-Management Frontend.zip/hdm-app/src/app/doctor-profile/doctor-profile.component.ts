import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DocservicsService } from '../docservics.service';
import { Doctor } from '../doctor';
import { Message } from '../message';

@Component({
  selector: 'app-doctor-profile',
  templateUrl: './doctor-profile.component.html',
  styleUrls: ['./doctor-profile.component.css']
})
export class DoctorProfileComponent implements OnInit {

  doctor: Doctor = new Doctor();
  id: number = 0;
  lid:number=0;
  message: Message = new Message();
  constructor(
    private service: DocservicsService,
    private activeRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
     this.lid = JSON.parse(sessionStorage.getItem('username') || '{}');
    this.doctor = new Doctor();
  //   // this.router.navigate(['empprofile']);
  //   this.id = this.activeRouter.snapshot.params['lid'];
  //   console.log(this.lid)
    // this.id = this.activeRouter.snapshot.params['lid'];
    this.service.getOneDoctor(this.lid).subscribe((data) => {
      this.router.navigate(['docprof']);
      this.doctor = data;
      let uname=this.doctor.name;
      sessionStorage.setItem('uname',uname);
    });
  }
  updatedoc(){
    this.service.updateDoctor(this.doctor).subscribe((data) => {
      console.log(data), this.router.navigate(['dochome']);
    });
  }

}
