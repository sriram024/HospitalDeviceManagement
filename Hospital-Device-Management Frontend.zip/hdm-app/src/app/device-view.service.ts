import { Injectable } from '@angular/core';
import { Observable } from'rxjs'; 
import { HttpClient } from'@angular/common/http';
import {DeviceView} from './device-view';


@Injectable({
  providedIn: 'root'
})
export class DeviceViewService {

private baseUrl: string = 'http://localhost:8001/Device';
  constructor(private http: HttpClient) {}

  listAllRecords(): Observable<DeviceView[]> {
    return this.http.get<DeviceView[]>(`${this.baseUrl}/all`);
  }
}