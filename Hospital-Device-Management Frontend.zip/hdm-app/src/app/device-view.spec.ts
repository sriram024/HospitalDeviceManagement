import { DeviceView } from './device-view';

describe('DeviceView;', () => {
  it('should create an instance', () => {
    expect(new DeviceView()).toBeTruthy();
  });
});
