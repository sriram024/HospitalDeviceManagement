export class Adminre {
    rid:number=0;
    dname:string='';
    dename:string='';
    statusss:string=''; 
}
