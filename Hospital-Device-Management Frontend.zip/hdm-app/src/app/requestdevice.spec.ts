import { Requestdevice } from './requestdevice';

describe('Requestdevice;', () => {
  it('should create an instance', () => {
    expect(new Requestdevice()).toBeTruthy();
  });
});
