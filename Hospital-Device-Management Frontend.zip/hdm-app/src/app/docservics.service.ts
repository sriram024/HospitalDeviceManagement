import { Injectable } from '@angular/core';
import { Doctor } from './doctor';

// import { Injectable } from '@angular/core';
import { HttpClient } from'@angular/common/http';
import { User } from'./user'; 
import { Observable } from'rxjs'; 
import { Message } from'./message'; 
import {HttpClientModule } from'@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class DocservicsService {

  private baseUrl: string = 'http://localhost:8001/doctor';
  constructor(private http: HttpClient) {}

  getAllDoctor(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.baseUrl}/all`);
  }
  deleteOneDoctor(id: number): Observable<Message> {
    return this.http.delete<Message>(`${this.baseUrl}/remove/${id}`);
  }
  createDoctor(doctor: Doctor): Observable<Message> {
    return this.http.post<Message>(`${this.baseUrl}/doctorsave`, doctor);
  }
  getOneDoctor(id: number): Observable<Doctor> {
    return this.http.get<Doctor>(`${this.baseUrl}/one/${id}`);
  }
  updateDoctor(doctor: Doctor): Observable<Message> {
    return this.http.put<Message>(`${this.baseUrl}/update`, doctor);
  }
}
