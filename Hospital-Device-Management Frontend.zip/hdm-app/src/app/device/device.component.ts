import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Message } from '../message';
import { DeviceView } from '../device-view';
import { DeviceViewService} from '../device-view.service';
import { Requestdevice } from '../requestdevice';

@Component({
  selector: 'app-device',
  templateUrl: './device.component.html',
  styleUrls: ['./device.component.css'],
})
export class DeviceComponent implements OnInit {
  device: DeviceView[] = [];
  message: Message = new Message();
  doctor: Requestdevice = new Requestdevice();
  request: Requestdevice[] = [];
  constructor(private ser: DeviceViewService, private router: Router) {}

  ngOnInit(): void {
    this.listAllRecord();
  }
  listAllRecord() {
    this.ser.listAllRecords().subscribe(
      (data) => {
        this.device = data;
      },
      (error) => {
        this.device = [];
      }
    );
  }
  viewrequest(did:number){
    this.router.navigate(['req']);
}
}
