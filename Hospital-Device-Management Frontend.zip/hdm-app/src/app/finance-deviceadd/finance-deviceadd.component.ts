import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Device } from '../device';
import { DeviceservService } from '../deviceserv.service';
import { Message } from '../message';

@Component({
  selector: 'app-finance-deviceadd',
  templateUrl: './finance-deviceadd.component.html',
  styleUrls: ['./finance-deviceadd.component.css']
})
export class FinanceDeviceaddComponent implements OnInit {

  doctor: Device = new Device();
  message: Message = new Message();
  constructor(private service: DeviceservService, private router: Router) {}

  ngOnInit(): void {}

  createDoctor() {
    this.service.createDoctor(this.doctor).subscribe((data) => {
      this.message = data;
    });
    this.doctor = new Device();
  }
}
