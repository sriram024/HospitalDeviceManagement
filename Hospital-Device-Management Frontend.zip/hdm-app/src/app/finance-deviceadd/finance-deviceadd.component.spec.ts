import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceDeviceaddComponent } from './finance-deviceadd.component';

describe('FinanceDeviceaddComponent', () => {
  let component: FinanceDeviceaddComponent;
  let fixture: ComponentFixture<FinanceDeviceaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinanceDeviceaddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceDeviceaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
