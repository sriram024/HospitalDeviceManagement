import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { Message } from '../message';
import { Requestdevice } from '../requestdevice';
import { RequestserviceService } from '../requestservice.service';

@Component({
  selector: 'app-reques-admin',
  templateUrl: './reques-admin.component.html',
  styleUrls: ['./reques-admin.component.css']
})
export class RequesAdminComponent implements OnInit {
  employee: Requestdevice = new Requestdevice();
  request: Requestdevice[] = [];
  message: Message = new Message();
  id: number = 0;
  constructor(private service: RequestserviceService, private router: Router, private activeRouter: ActivatedRoute,){}

  ngOnInit(): void {
    this.listAllRecords();
    
  }
  listAllRecords() {
    this.service.listAllRecords().subscribe(
      (data) => {
        this.request = data;
      },
      (error) => {
        this.request = [];
      }
    );
  }
  deleteEmployee(id: number) {
    this.service.deleteById(id).subscribe(
      (data) => {
        (this.message = data)
        alert("Rejected successfully..")
      },
      (error) => {
        console.log(error);
      }
    );

}

updatestatus(lid:number){
  this.router.navigate(['updstsad',lid]);
  

}

}

