import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequesAdminComponent } from './reques-admin.component';

describe('RequesAdminComponent', () => {
  let component: RequesAdminComponent;
  let fixture: ComponentFixture<RequesAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequesAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequesAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
