export class DeviceView {
  did: number = 0;
  ddesc: String = '';
  dname: string = '';
}
