import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-finance-admin',
  templateUrl: './update-finance-admin.component.html',
  styleUrls: ['./update-finance-admin.component.css']
})
export class UpdateFinanceAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
