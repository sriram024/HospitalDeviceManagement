import { Adminre } from './adminre';

describe('Adminre', () => {
  it('should create an instance', () => {
    expect(new Adminre()).toBeTruthy();
  });
});
