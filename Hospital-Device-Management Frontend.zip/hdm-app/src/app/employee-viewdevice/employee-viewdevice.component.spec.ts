import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeViewdeviceComponent } from './employee-viewdevice.component';

describe('EmployeeViewdeviceComponent', () => {
  let component: EmployeeViewdeviceComponent;
  let fixture: ComponentFixture<EmployeeViewdeviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeViewdeviceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeViewdeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
