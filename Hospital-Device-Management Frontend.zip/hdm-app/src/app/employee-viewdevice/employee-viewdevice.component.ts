import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Device } from '../device';
import { DeviceservService } from '../deviceserv.service';
import { Message } from '../message';
import { RequestserviceService } from '../requestservice.service';

@Component({
  selector: 'app-employee-viewdevice',
  templateUrl: './employee-viewdevice.component.html',
  styleUrls: ['./employee-viewdevice.component.css']
})
export class EmployeeViewdeviceComponent implements OnInit {

  dd: Device[] = [];
  message: Message = new Message();

  constructor(private service: DeviceservService, private router: Router) {}

  ngOnInit(): void {
    this.listAllRecords();
  }
  listAllRecords() {
    this.service.getAlldevice().subscribe(
      (data) => {
        this.dd = data;
      },
      (error) => {
        this.dd = [];
      }
    );
  }

}
