// import { Devicereques } from './devicereques';

// describe('Devicereques', () => {
//   it('should create an instance', () => {
//     expect(new Devicereques()).toBeTruthy();
//   });
// });
