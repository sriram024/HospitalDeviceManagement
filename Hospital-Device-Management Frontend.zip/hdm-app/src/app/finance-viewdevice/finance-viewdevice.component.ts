import { Component, OnInit } from '@angular/core';
import { Device } from '../device';
import { Message } from '../message';
import { DeviceservService } from '../deviceserv.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-finance-viewdevice',
  templateUrl: './finance-viewdevice.component.html',
  styleUrls: ['./finance-viewdevice.component.css']
})
export class FinanceViewdeviceComponent implements OnInit {
  dd: Device[] = [];
  message: Message = new Message();

  constructor(private service: DeviceservService, private router: Router) {}

  ngOnInit(): void {
    this.listAllRecords();
  }
  listAllRecords() {
    this.service.getAlldevice().subscribe(
      (data) => {
        this.dd = data;
      },
      (error) => {
        this.dd = [];
      }
    );
  }
  deleteFinance(id: number) {
    this.service.deleteOneDoctor(id).subscribe(
      (data) => {
        (this.message = data)
        alert("Deleted successfully..!")
      },
      (error) => {
        console.log(error);
      }
    );
}
onClick(n:number){
  this.router.navigate(['deviceedit',n]);
}
editDoctor(id: number) {
  this.router.navigate(['edit', id]);
}
}