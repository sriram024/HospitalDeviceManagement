import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceViewdeviceComponent } from './finance-viewdevice.component';

describe('FinanceViewdeviceComponent', () => {
  let component: FinanceViewdeviceComponent;
  let fixture: ComponentFixture<FinanceViewdeviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinanceViewdeviceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceViewdeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
