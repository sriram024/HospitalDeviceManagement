import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoctorSendrequestComponent } from './doctor-sendrequest.component';

describe('DoctorSendrequestComponent', () => {
  let component: DoctorSendrequestComponent;
  let fixture: ComponentFixture<DoctorSendrequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DoctorSendrequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DoctorSendrequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
