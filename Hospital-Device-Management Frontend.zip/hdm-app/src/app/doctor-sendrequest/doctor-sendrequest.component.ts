import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Docreq } from '../docreq';
import { Employee } from '../employee';
import { Message } from '../message';
import { SendreqdocService } from '../sendreqdoc.service';

@Component({
  selector: 'app-doctor-sendrequest',
  templateUrl: './doctor-sendrequest.component.html',
  styleUrls: ['./doctor-sendrequest.component.css']
})
export class DoctorSendrequestComponent implements OnInit {
  uname:number=0;
  doctor: Docreq = new Docreq();
  message: Message = new Message();
  did:number=0;
 
  constructor(private service: SendreqdocService, private router: Router,private route: ActivatedRoute) {}

  ngOnInit(): void {
    // this.uname = JSON.parse(sessionStorage.getItem('username') || '{}');
    // // let uname=sessionStorage.getItem('uname');
    // this.route.params.subscribe(
    //   (params: Params) => {
    //     console.log(params['did']);
    //     this.did=params['did']
    //   }
    // );

    // this.doctor = new Docreq();
    // this.doctor.devicename = this.did;
    // this.doctor.doctorname = this.uname;
    // this.doctor.status="pending";
  }

  createReq() {
    this.service.createReq(this.doctor).subscribe((data) => {
      console.log(data);
      this.message = data;
    });
    this.doctor = new Docreq();
  }
}
