import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Finance } from '../finance';
import { FinanceserviceService } from '../financeservice.service';
import { Requestdevice } from '../requestdevice';
import { RequestserviceService } from '../requestservice.service';

@Component({
  selector: 'app-update-status-admin',
  templateUrl: './update-status-admin.component.html',
  styleUrls: ['./update-status-admin.component.css']
})
export class UpdateStatusAdminComponent implements OnInit {
  employee: Requestdevice = new Requestdevice();
  id: number = 0;
  doctor: Finance[] = [];
  constructor(
    private service: RequestserviceService, private router: Router, private activeRouter: ActivatedRoute,private service2: FinanceserviceService
  ) {}

  ngOnInit(): void {
  //  this.listAllRecords();
    this.employee = new Requestdevice();
    this.id = this.activeRouter.snapshot.params['id'];
    this.service.getEmployeeById(this.id).subscribe((data) => {  
        this.employee = data;
        console.log(this.employee.rid);
        this.employee.statusss="Forwarded"; 
      
    });
    // this.service2.listAllRecords().subscribe(
    //   (data) => {
    //     this.doctor = data;
    //   },
    //   (error) => {
    //     this.doctor = [];
    //   }
    // );
  }
  updateDoctor() {
    // this.employee.statusss="Forwarded";
    this.service.updateFinance(this.employee).subscribe((data) => {
      alert("Forwarded successfully.."), this.router.navigate(['req']);
    });
  }
}