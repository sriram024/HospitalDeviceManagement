import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateStatusAdminComponent } from './update-status-admin.component';

describe('UpdateStatusAdminComponent', () => {
  let component: UpdateStatusAdminComponent;
  let fixture: ComponentFixture<UpdateStatusAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateStatusAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateStatusAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
