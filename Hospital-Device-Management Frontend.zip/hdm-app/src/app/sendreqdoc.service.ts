import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Docreq } from './docreq';
import { Message } from './message';

@Injectable({
  providedIn: 'root'
})
export class SendreqdocService {
  private baseUrl: string = 'http://localhost:8001/request';
  constructor(private http: HttpClient) {}

  
  createReq(request: Docreq): Observable<Message> {
    return this.http.post<Message>(`${this.baseUrl}/requestadd`, request);
 
}
}
