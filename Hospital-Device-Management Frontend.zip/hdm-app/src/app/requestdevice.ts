export class Requestdevice { 
        rid:number=0;
        dname:number=0;
        dename:number=0;
        statusss:string=''; 
        fid:number=0;   
        
    }
    
