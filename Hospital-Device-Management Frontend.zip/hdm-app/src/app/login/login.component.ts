import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from '../login-service.service';
import { User } from '../user';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:User=new User();

  constructor(private  loginServiceService:LoginServiceService,private route: ActivatedRoute,
    private router: Router,) {}
  

  ngOnInit(): void {
  }

  userLogin(){
    console.log(this.user);
    var type=this.user.type;

    if(type=='Employee'){
      this.loginServiceService.createStudent(this.user).subscribe(data=>{
        // alert("login successfully")
        let un=this.user.username;
        sessionStorage.setItem('username',un);
        console.log(un);
        // this.router.navigate([EmployeeComponent]);
        this.router.navigate(['/', 'emphome'], { relativeTo: this.route })
        .then(nav => {
          console.log(nav); // true if navigation is successful
        }, err => {
          console.log(err) // when there's an error
        });
      },error=>alert("Invalid user"));
    }
    else if(type=='Doctor'){
      this.loginServiceService.createDoctor(this.user).subscribe(data=>{
        alert("login successfully doctor")
        let un=this.user.username;
        sessionStorage.setItem('username',un);
        // this.router.navigate([EmployeeComponent]);
        this.router.navigate(['/', 'dochome'], { relativeTo: this.route })
        .then(nav => {
          console.log(nav); // true if navigation is successful
        }, err => {
          console.log(err) // when there's an error
        });
      },error=>alert("Invalid user"));
    }
    else if(type=='Finance'){
      this.loginServiceService.createFinance(this.user).subscribe(data=>{
        alert("login successfully Finance")
        let un=this.user.username;
        sessionStorage.setItem('username',un);
        // this.router.navigate([EmployeeComponent]);
        this.router.navigate(['/', 'finhome'], { relativeTo: this.route })
        .then(nav => {
          console.log(nav); // true if navigation is successful
        }, err => {
          console.log(err) // when there's an error
        });
      },error=>alert("Invalid user"));
    }
    else if(type=='Admin'){
      this.loginServiceService.createAdmin(this.user).subscribe(data=>{
        alert("login successfully Admin")
        let un=this.user.username;
        console.log(un);
        sessionStorage.setItem('username',un);
        // this.router.navigate([EmployeeComponent]);
        this.router.navigate(['/', 'home'], { relativeTo: this.route })
        .then(nav => {
          console.log(nav); // true if navigation is successful
        }, err => {
          console.log(err) // when there's an error
        });
      },error=>alert("Invalid user"));
    }
  }

}
