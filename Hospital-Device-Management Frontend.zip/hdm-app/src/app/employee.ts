export class Employee {
  empId: number = 0;
  empName: string = ' ';
  designation: string = '';
  emailid: string = '';
  phonenumber: number = 0;
  password:string='';
}
