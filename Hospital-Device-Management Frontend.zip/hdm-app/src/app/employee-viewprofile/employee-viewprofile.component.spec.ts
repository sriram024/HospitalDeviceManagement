import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeViewprofileComponent } from './employee-viewprofile.component';

describe('EmployeeViewprofileComponent', () => {
  let component: EmployeeViewprofileComponent;
  let fixture: ComponentFixture<EmployeeViewprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeViewprofileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeViewprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
