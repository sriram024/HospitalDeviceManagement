import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmpserviceService } from '../empservice.service';
import { Message } from '../message';

@Component({
  selector: 'app-employee-viewprofile',
  templateUrl: './employee-viewprofile.component.html',
  styleUrls: ['./employee-viewprofile.component.css']
})
export class EmployeeViewprofileComponent implements OnInit {

  employee: Employee = new Employee();
  id: number = 0;
  lid:number=0;
  message: Message = new Message();
  constructor(
    private service: EmpserviceService,
    private activeRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
     this.lid = JSON.parse(sessionStorage.getItem('username') || '{}');
    this.employee = new Employee();
  //   // this.router.navigate(['empprofile']);
  //   this.id = this.activeRouter.snapshot.params['lid'];
  //   console.log(this.lid)
    // this.id = this.activeRouter.snapshot.params['lid'];
    this.service.getEmployeeById(this.lid).subscribe((data) => {
      this.router.navigate(['empprofile']);
      this.employee = data;
    });
  }
  addEmployee(){
    this.service.updateEmployee(this.employee).subscribe((data) => {
      console.log(data), this.router.navigate(['emphome']);
    });
  }
}
