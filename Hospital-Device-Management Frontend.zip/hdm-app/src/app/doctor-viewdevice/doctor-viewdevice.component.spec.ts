import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoctorViewdeviceComponent } from './doctor-viewdevice.component';

describe('DoctorViewdeviceComponent', () => {
  let component: DoctorViewdeviceComponent;
  let fixture: ComponentFixture<DoctorViewdeviceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DoctorViewdeviceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DoctorViewdeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
