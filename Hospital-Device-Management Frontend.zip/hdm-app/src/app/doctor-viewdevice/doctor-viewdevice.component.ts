import { Component, OnInit } from '@angular/core';
import { Device } from '../device';
import { Message } from '../message';
import { DeviceservService } from '../deviceserv.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-doctor-viewdevice',
  templateUrl: './doctor-viewdevice.component.html',
  styleUrls: ['./doctor-viewdevice.component.css']
})
export class DoctorViewdeviceComponent implements OnInit {
 deviceid:number=0;
   dd: Device[] = [];
  message: Message = new Message();
  employee: Device = new Device();

  constructor(private service: DeviceservService, private router: Router) {}

  ngOnInit(): void {
    this.listAllRecords();
  }
  listAllRecords() {
    this.service.getAlldevice().subscribe(
      (data) => {
        this.dd = data;
      },
      (error) => {
        this.dd = [];
      }
    );
  }
  sendrequest(did:number){
    this.deviceid=did;
    // this.service.getDeviceById(this.deviceid).subscribe((data) => {
      this.router.navigate(['sendreq',this.deviceid]);
      // this.employee = data;
   
    // sessionStorage.setItem('did',this.deviceid);
    // this.router.navigate(['sendreq',this.deviceid]);
  // });
}
}
