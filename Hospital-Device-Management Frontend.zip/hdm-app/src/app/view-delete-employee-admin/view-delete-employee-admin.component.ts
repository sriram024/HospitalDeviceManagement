import { Component, OnInit } from '@angular/core';
import { EmpserviceService } from '../empservice.service';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { Message } from '../message'; 
 

@Component({
  selector: 'app-view-delete-employee-admin',
  templateUrl: './view-delete-employee-admin.component.html',
  styleUrls: ['./view-delete-employee-admin.component.css'],
})
export class ViewDeleteEmployeeAdminComponent implements OnInit {
  employee: Employee[] = [];
  message: Message = new Message();

  constructor(private service: EmpserviceService, private router: Router) {}

  ngOnInit(): void {
    this.listAllRecords();
  }
  listAllRecords() {
    this.service.listAllRecords().subscribe(
      (data) => {
        this.employee = data;
      },
      (error) => {
        this.employee = [];
      }
    );
  }
  deleteEmployee(id: number) {
    this.service.deleteById(id).subscribe(
      (data) => {
        (this.message = data), this.listAllRecords();
      },
      (error) => {
        console.log(error);
      }
    );
  }
  editEmployee(id: number) {
    this.router.navigate(['edit', id]);
  }
}
