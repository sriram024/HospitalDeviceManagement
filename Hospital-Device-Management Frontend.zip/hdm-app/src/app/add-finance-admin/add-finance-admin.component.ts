import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Finance } from '../finance';
import { FinanceserviceService } from '../financeservice.service';
import { Message } from '../message'; 

@Component({
  selector: 'app-add-finance-admin',
  templateUrl: './add-finance-admin.component.html',
  styleUrls: ['./add-finance-admin.component.css']
})
export class AddFinanceAdminComponent implements OnInit {

  finance: Finance = new Finance();
  message: Message = new Message();
  constructor(private service: FinanceserviceService, private router: Router) {}

  ngOnInit(): void {}
    addFinancea() {
      this.service.addFinance(this.finance).subscribe((data) => {
        this.message = data;
        console.log(this.finance);
      });
      this.finance = new Finance();
  

}
}