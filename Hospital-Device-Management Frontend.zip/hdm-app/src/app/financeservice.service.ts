import { Injectable } from '@angular/core';
import { Finance } from './finance';

// import { Injectable } from '@angular/core';
import { HttpClient } from'@angular/common/http';
import { User } from'./user'; 
import { Observable } from'rxjs'; 
import { Message } from'./message'; 
import {HttpClientModule } from'@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class FinanceserviceService {

  private baseUrl: string = 'http://localhost:8001/finance';
  constructor(private http: HttpClient) {}

  listAllRecords(): Observable<Finance[]> {
    return this.http.get<Finance[]>(`${this.baseUrl}/all`);
  }
  // deleteById(id: number): Observable<Message> {
  //   return this.http.delete<Message>(`${this.baseUrl}/delete/${id}`);
  // }
  addFinance(finance: Finance): Observable<Message> {
    return this.http.post<Message>(`${this.baseUrl}/save`, finance);
  }
  deleteOneFinance(id: number): Observable<Message> {
    return this.http.delete<Message>(`${this.baseUrl}/remove/${id}`);
  }
  getFinanceById(id: number): Observable<Finance> {
    return this.http.get<Finance>(`${this.baseUrl}/one/${id}`);
  }
  updateFinance(employee: Finance): Observable<Message> {
    return this.http.put<Message>(`${this.baseUrl}/update`, employee);
  }
  
}
