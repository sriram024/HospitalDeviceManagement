import { Docreq } from './docreq';

describe('Docreq', () => {
  it('should create an instance', () => {
    expect(new Docreq()).toBeTruthy();
  });
});
