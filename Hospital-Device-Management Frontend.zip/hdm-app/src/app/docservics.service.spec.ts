import { TestBed } from '@angular/core/testing';

import { DocservicsService } from './docservics.service';

describe('DocservicsService', () => {
  let service: DocservicsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DocservicsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
