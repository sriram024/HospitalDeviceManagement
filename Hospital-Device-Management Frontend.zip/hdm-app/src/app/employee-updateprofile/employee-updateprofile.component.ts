import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-updateprofile',
  templateUrl: './employee-updateprofile.component.html',
  styleUrls: ['./employee-updateprofile.component.css']
})
export class EmployeeUpdateprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
