import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeUpdateprofileComponent } from './employee-updateprofile.component';

describe('EmployeeUpdateprofileComponent', () => {
  let component: EmployeeUpdateprofileComponent;
  let fixture: ComponentFixture<EmployeeUpdateprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeeUpdateprofileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeUpdateprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
