import { Component, OnInit } from '@angular/core';
import { EmpserviceService } from '../empservice.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee'; 

@Component({
  selector: 'app-update-employee-admin',
  templateUrl: './update-employee-admin.component.html',
  styleUrls: ['./update-employee-admin.component.css'],
})
export class UpdateEmployeeAdminComponent implements OnInit {
  employee: Employee = new Employee();
  id: number = 0;

  constructor(
    private service: EmpserviceService,
    private activeRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.employee = new Employee();
    this.id = this.activeRouter.snapshot.params['id'];
    this.service.getEmployeeById(this.id).subscribe((data) => {
      this.employee = data;
    });
  }
  updateEmployee() {
    this.service.updateEmployee(this.employee).subscribe((data) => {
      console.log(data), this.router.navigate(['all']);
      
    });
  }
}
