import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Device } from '../device';
import { Message } from '../message';
import { Requestdevice } from '../requestdevice';
import { RequestserviceService } from '../requestservice.service';

@Component({
  selector: 'app-finance-approverejectreq',
  templateUrl: './finance-approverejectreq.component.html',
  styleUrls: ['./finance-approverejectreq.component.css'],
})
export class FinanceApproverejectreqComponent implements OnInit {
  deviceid: number = 0;
  dd: Requestdevice[] = [];
  mvcd: Requestdevice[] = [];
  requestdevice1: Requestdevice[] = [];
  message: Message = new Message();
  code2: String = '';
  employee: Requestdevice = new Requestdevice();
  lid: number = 0;
  constructor(private service: RequestserviceService, private router: Router) {
    // this.service.getFinanceID(this.code2)
  }

  ngOnInit(): void {
    // this.getdetails();
    this.listall();
  }

  updatestatus(d: number) {
    this.router.navigate(['updatestsfin', d]);
  }

  getdetails() {
    this.lid = JSON.parse(sessionStorage.getItem('username') || '{}');
    this.employee = new Requestdevice();
    //   // this.router.navigate(['empprofile']);
    //   this.id = this.activeRouter.snapshot.params['lid'];
    //   console.log(this.lid)
    // this.id = this.activeRouter.snapshot.params['lid'];
    this.service.getFinanceID(this.lid).subscribe((data) => {
      this.router.navigate(['updatestsfin', this.lid]);
      this.employee = data;
    });
  }

  listall() {
    this.service.listAllRecords().subscribe(
      (data) => {
        this.requestdevice1 = data;
      },
      (error) => {
        this.requestdevice1 = [];
      }
    );
  }
}
