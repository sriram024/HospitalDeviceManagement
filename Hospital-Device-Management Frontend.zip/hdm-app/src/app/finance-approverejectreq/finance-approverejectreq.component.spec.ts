import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceApproverejectreqComponent } from './finance-approverejectreq.component';

describe('FinanceApproverejectreqComponent', () => {
  let component: FinanceApproverejectreqComponent;
  let fixture: ComponentFixture<FinanceApproverejectreqComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinanceApproverejectreqComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceApproverejectreqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
