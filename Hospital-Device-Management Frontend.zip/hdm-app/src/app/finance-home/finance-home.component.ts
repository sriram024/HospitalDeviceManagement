import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Finance } from '../finance';
import { FinanceserviceService } from '../financeservice.service';

import { Device } from '../device';
import { Message } from '../message';
import { Requestdevice } from '../requestdevice';
import { RequestserviceService } from '../requestservice.service';


@Component({
  selector: 'app-finance-home',
  templateUrl: './finance-home.component.html',
  styleUrls: ['./finance-home.component.css'],
})
export class FinanceHomeComponent implements OnInit {
  employee: Finance = new Finance();
  finance: Requestdevice = new Requestdevice();
  id: number = 0;
  lid: number = 0;
  selectedDev: string = '';
  constructor(
    private service: FinanceserviceService,
    private activeRouter: ActivatedRoute,
    private router: Router,
    private service1: RequestserviceService
  ) {}

  ngOnInit(): void {}

  onclick() {
    this.router.navigate(['finrpfilr']);
  }
  selectChangeHandler(event: any) {
    //update the ui
    var i = document.getElementById('doc');

    if (event.target == i) {
      console.log(event.target);
      this.selectedDev = event.target.value;
      if (this.selectedDev == 'Add') {
        this.router.navigate(['adddevice']);
        console.log(this.selectedDev);
      }
      if (this.selectedDev == 'view') {
        this.router.navigate(['viewdevice']);
      }
    }
  }
  onclick3() {
    sessionStorage.removeItem('username');
    this.router.navigate(['front']);
  }
  onclick2() {
    this.lid = JSON.parse(sessionStorage.getItem('username') || '{}');
    this.finance = new Requestdevice();
    //   // this.router.navigate(['empprofile']);
    //   this.id = this.activeRouter.snapshot.params['lid'];
    //   console.log(this.lid)
    // this.id = this.activeRouter.snapshot.params['lid'];
    this.service1.getFinanceID(this.lid).subscribe((data) => {
      this.router.navigate(['viewreqfin', this.lid]);
      this.finance = data;
    });
    // this.router.navigate(['viewreqfin']);
  }

  // getValidation(tx1: any) {
  //   this.service.getAllCustomer().subscribe(
  //     (data) => {
  //       this.customer = data;
  //     },
  //     (error) => {
  //       this.customer = [];
  //     }
  //   );
  //   //calling a service class method
  //   for (let s of this.customer) {
  //     if (this.username == s.cuser && this.upwd == s.cpwd) {
  //       this.msg = 'Successfully Login';
  //       this.msg2 = this.msg;
  //       this.route.navigateByUrl('/opdt');
  //     } else {
  //       this.msg = 'Username or Password Incorrect';
  //       tx1.focus;
        
  //     }
  //     this.msg1 = this.msg;
  //   }
  // }
       
}
