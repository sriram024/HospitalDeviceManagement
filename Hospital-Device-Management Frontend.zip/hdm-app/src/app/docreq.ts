export class Docreq {
    sid:number=0;
    doctorname:number=0;
    devicename:number=0;
    status:string="";
    
}
