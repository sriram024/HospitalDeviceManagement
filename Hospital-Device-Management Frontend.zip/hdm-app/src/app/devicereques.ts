// export class Devicereques {
//     sid:number=0;
//     doctorname:string="";
//     devicename:string="";
//     status:string="";
// }
