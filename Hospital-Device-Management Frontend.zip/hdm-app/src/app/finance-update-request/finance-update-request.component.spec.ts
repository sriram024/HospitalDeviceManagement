import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceUpdateRequestComponent } from './finance-update-request.component';

describe('FinanceUpdateRequestComponent', () => {
  let component: FinanceUpdateRequestComponent;
  let fixture: ComponentFixture<FinanceUpdateRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinanceUpdateRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceUpdateRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
