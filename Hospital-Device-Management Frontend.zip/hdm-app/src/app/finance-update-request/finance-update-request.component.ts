import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Requestdevice } from '../requestdevice';
import { RequestserviceService } from '../requestservice.service';

@Component({
  selector: 'app-finance-update-request',
  templateUrl: './finance-update-request.component.html',
  styleUrls: ['./finance-update-request.component.css']
})
export class FinanceUpdateRequestComponent implements OnInit {
  employee: Requestdevice = new Requestdevice();
  id: number = 0;

  constructor(
    private service: RequestserviceService, private router: Router, private activeRouter: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.employee = new Requestdevice();
    this.id = this.activeRouter.snapshot.params['id'];
    this.service.getEmployeeById(this.id).subscribe((data) => {
     
        this.employee = data;
        console.log(this.employee.rid);
        // this.employee.statusss="Forwarded"
    
      
    });
   
  }
  updateDoctor() {
    // this.employee.statusss="Forwarded";
    this.service.updateFinance(this.employee).subscribe((data) => {
      alert("Updated successfully.."), this.router.navigate(['viewreqfin']);
    });
  }

}

