import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AddDoctorAdminComponent } from './add-doctor-admin/add-doctor-admin.component';
import { AddEmployeeAdminComponent } from './add-employee-admin/add-employee-admin.component';
import { AddFinanceAdminComponent } from './add-finance-admin/add-finance-admin.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { ContactusComponent } from './contactus/contactus.component';
import { DeviceComponent } from './device/device.component';
import { DoctorProfileComponent } from './doctor-profile/doctor-profile.component';
import { DoctorSendrequestComponent } from './doctor-sendrequest/doctor-sendrequest.component';
import { DoctorViewdeviceComponent } from './doctor-viewdevice/doctor-viewdevice.component';
import { DoctorViewprofileComponent } from './doctor-viewprofile/doctor-viewprofile.component';
import { EmployeeHomeComponent } from './employee-home/employee-home.component';
import { EmployeeViewdeviceComponent } from './employee-viewdevice/employee-viewdevice.component';
import { EmployeeViewprofileComponent } from './employee-viewprofile/employee-viewprofile.component';
import { FinanceApproverejectreqComponent } from './finance-approverejectreq/finance-approverejectreq.component';
import { FinanceDeviceaddComponent } from './finance-deviceadd/finance-deviceadd.component';
import { FinanceDeviceeditComponent } from './finance-deviceedit/finance-deviceedit.component';
import { FinanceHomeComponent } from './finance-home/finance-home.component';
import { FinanceUpdateRequestComponent } from './finance-update-request/finance-update-request.component';
import { FinanceViewdeviceComponent } from './finance-viewdevice/finance-viewdevice.component';
import { FinanceViewprofileComponent } from './finance-viewprofile/finance-viewprofile.component';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { LoginComponent } from './login/login.component';
import { RequesAdminComponent } from './reques-admin/reques-admin.component';
import { SendReqDocComponent } from './send-req-doc/send-req-doc.component';
import { UpdateDoctorAdminComponent } from './update-doctor-admin/update-doctor-admin.component';
import { UpdateEmployeeAdminComponent } from './update-employee-admin/update-employee-admin.component';
import { UpdateFinanceAdminComponent } from './update-finance-admin/update-finance-admin.component';
import { UpdateStatusAdminComponent } from './update-status-admin/update-status-admin.component';
import { ViewDeleteDoctorAdminComponent } from './view-delete-doctor-admin/view-delete-doctor-admin.component';
import { ViewDeleteEmployeeAdminComponent } from './view-delete-employee-admin/view-delete-employee-admin.component';
import { ViewDeleteFinanceAdminComponent } from './view-delete-finance-admin/view-delete-finance-admin.component';

const routes: Routes =  [ 
  { path: 'add-doc', component: AddDoctorAdminComponent },
  { path: 'home', component: AdminHomeComponent },
  { path: 'add-emp', component: AddEmployeeAdminComponent },
  { path: 'add-fin', component: AddFinanceAdminComponent },
  { path: 'dev', component: DeviceComponent },
  { path: 'login', component: LoginComponent },
  { path: 'about', component: AboutusComponent },
  { path: 'contact', component: ContactusComponent },
  { path: 'req', component: RequesAdminComponent },
  { path: 'doc/:id', component: UpdateDoctorAdminComponent },
  { path: 'emp/:id', component: UpdateEmployeeAdminComponent },
  { path: 'fin/:id', component: UpdateFinanceAdminComponent },
  { path: 'view-doc', component: ViewDeleteDoctorAdminComponent },
  { path: 'view-emp', component: ViewDeleteEmployeeAdminComponent },
  { path: 'view-fin', component: ViewDeleteFinanceAdminComponent },
  { path: 'front', component: FrontpageComponent },
  { path: 'updstsad/:id', component: UpdateStatusAdminComponent },

  // Employee
  { path: 'emphome', component: EmployeeHomeComponent },
  { path: 'empprofile', component: EmployeeViewprofileComponent },
  { path: 'viewdev', component: EmployeeViewdeviceComponent },

  //Doctor
  { path: 'dochome', component: DoctorViewprofileComponent },
  { path: 'docprof', component: DoctorProfileComponent },
  { path: 'sendreq/:did', component: SendReqDocComponent },
  { path: 'viewdevdoc', component: DoctorViewdeviceComponent },

  //device
  { path: 'dev', component: DeviceComponent },

  
//finance
{ path: 'finhome', component: FinanceHomeComponent },
{ path: 'finrpfilr', component: FinanceViewprofileComponent },
{ path: 'adddevice', component: FinanceDeviceaddComponent },
{ path: 'viewdevice', component: FinanceViewdeviceComponent },
{ path: 'viewreqfin/:id', component: FinanceApproverejectreqComponent },
{ path: 'deviceedit/:id', component: FinanceDeviceeditComponent },
{ path: 'updatestsfin/:id', component: FinanceUpdateRequestComponent },


  { path: '', redirectTo: 'front', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
