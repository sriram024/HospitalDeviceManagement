import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Doctor } from '../doctor';
import { DocservicsService } from '../docservics.service';

@Component({
  selector: 'app-doctor-viewprofile',
  templateUrl: './doctor-viewprofile.component.html',
  styleUrls: ['./doctor-viewprofile.component.css']
})
export class DoctorViewprofileComponent implements OnInit {

  employee: Doctor = new Doctor();
  id: number = 0;
  lid:number=0;
  constructor(
    private service: DocservicsService,
    private activeRouter: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
  }
  onclick(){
    this.router.navigate(['docprof']);
}
onclick2(){
  this.router.navigate(['viewdevdoc']);
}
onclick3(){
sessionStorage.removeItem('username');
this.router.navigate(['front']);

}
}
