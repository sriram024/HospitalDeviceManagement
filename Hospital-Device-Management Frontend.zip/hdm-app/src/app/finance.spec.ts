import { Finance } from './finance';

describe('Finance', () => {
  it('should create an instance', () => {
    expect(new Finance()).toBeTruthy();
  });
});
