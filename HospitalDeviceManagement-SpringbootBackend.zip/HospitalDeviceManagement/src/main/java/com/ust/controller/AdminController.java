package com.ust.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.model.Admin;
import com.ust.model.Device;
import com.ust.model.Message;
import com.ust.model.User;
import com.ust.service.AdminServiceImpl;
import com.ust.service.EmployeeService;



@RestController 

@CrossOrigin(origins = "*") 
//@RequestMapping("/rest/student") 

@RequestMapping("/admin")
public class AdminController {
	
	//====================login for admin================================
	
	
	@Autowired
	AdminServiceImpl empserObj;
	
		@PostMapping("/saveadmin") 
		public ResponseEntity<?> loginadmin(@RequestBody User user) 
		 	{ 
			ResponseEntity<Message> resp=null; 
			
			System.out.println(user.getUsername());
			System.out.println(user.getPassword());
			
			Optional<Admin> use=empserObj.searchuseraadmin(user.getUsername());
			if(use.get().getPassword().equals(user.getPassword())) 
				return ResponseEntity.ok(use);
			
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
//	 	 	 	e.printStackTrace(); 
			}
		
		

}
