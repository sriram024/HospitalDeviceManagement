package com.ust.model;



import javax.persistence.Entity; 
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor; import lombok.Data; 
import lombok.NoArgsConstructor; import lombok.NonNull; 
import lombok.RequiredArgsConstructor; 
 
@Data 
@NoArgsConstructor 
@RequiredArgsConstructor 
@AllArgsConstructor 	
@Entity 
@Table(name="Doctor")
public class Doctor { 
 	@Id 
 	@GeneratedValue	
 	private Integer id;  		
 	@NonNull 
 	private String name; 
 	@NonNull 
 	private String qualification;
 	@NonNull 
 	private String email;  			
 	@NonNull 
 	private String gender;
 	@NonNull 
 	private String password;
 	
} 

