package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Finance;
import com.ust.repository.FinanceRepo;

@Service
public class FinanceServiceImpl implements  FinanceService{

	@Autowired 
 	private FinanceRepo repo; 

	@Override
	public Integer saveFinance(Finance s) {
		return repo.save(s).getFid(); 
	}

	@Override
	public List<Finance> getAllFinance() {
		return repo.findAll(); 
	}

	@Override
	public Optional<Finance> getOneFinance(Integer id) {
		return repo.findById(id); 
	}

	@Override
	public boolean isExist(Integer id) {
		 	return repo.existsById(id); 
	}

	@Override
	public void deleteFinance(Integer id) {
		repo.deleteById(id); 
		
	}
	
	//login

	@Override
	public Optional<Finance> searchusera(Integer username) {
		return repo.findById(username);
	}
	
	
	

}
