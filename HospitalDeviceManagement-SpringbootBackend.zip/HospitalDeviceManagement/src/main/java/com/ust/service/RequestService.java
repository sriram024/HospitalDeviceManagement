package com.ust.service;


import java.util.List;
import java.util.Optional;

import com.ust.model.status;

public interface RequestService {
	public Integer addrequst(status s);  
	public List<status> listAllrecords();
	
	public List<status> listAllrecordsbyfinance();
	public Optional<status> getRequestById(int id);
	
	public boolean isPresent(int id);
	
	public void updateRequest(status s);
	public Optional<status> getRequestByIdfinance(int id);
	
	public void updateStudentbyfinance(status s);
	public void deletereq(Integer id);
	
	public List<status> findByfid1 (String fid);
}
