package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.Doctor;
import com.ust.model.Employee;




public interface DoctorService { 
	
	
	public Integer saveDoctor(Doctor s);  	
	public List<Doctor> getAllDoctor();  	
	public Optional<Doctor> getOneDoctor(Integer id);  
	public boolean isExist(Integer id);  	
	public void deleteDoctor(Integer id);
	
	//login
	public Optional<Doctor> searchusera(Integer username); 
	 
} 
 