package com.ust.service;

import java.util.List; 
import java.util.Optional; 
 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;

import com.ust.model.Doctor;
import com.ust.repository.DoctorRepo; 
 
 


@Service 
public class DoctorServiceImpl implements DoctorService 
{ 
 	@Autowired 
 	private DoctorRepo repo; //HAS-A 
	
 	@Override 
 	public Integer saveDoctor(Doctor s) { 
 	 	return repo.save(s).getId();
 	} 
 	@Override 
 	public List<Doctor> getAllDoctor() {  	 		
 		return repo.findAll(); 
 	} 
 	  
 	@Override 
 	public Optional<Doctor> getOneDoctor(Integer id) { 
 	 	return repo.findById(id); 
 	} 
 	 
 	@Override 
 	public void deleteDoctor(Integer id) {  	 				
 		repo.deleteById(id); 
 	} 
 	 
 	@Override 
 	public boolean isExist(Integer id) {  	
 		return repo.existsById(id); 
}
 	
 	
 	//=============================================================================login
 	
 	
 	
 	
	@Override
	public Optional<Doctor> searchusera(Integer username) {
		return repo.findById(username);
	}
	
	
 
} 

