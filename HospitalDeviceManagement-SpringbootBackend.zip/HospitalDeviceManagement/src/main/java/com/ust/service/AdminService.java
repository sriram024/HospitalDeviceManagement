package com.ust.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Admin;
import com.ust.repository.Adminrepo;
import com.ust.repository.DeviceRepo;

@Service
public class AdminService implements AdminServiceImpl{
	
	@Autowired
	Adminrepo  arepo;


	@Override
	public Optional<Admin> searchuseraadmin(Integer username) {
		return arepo.findById(username);
	}

}
