package com.ust.service;

import java.util.Optional;

import com.ust.model.Admin;


public interface AdminServiceImpl {
	
	//login
		

		public Optional<Admin> searchuseraadmin(Integer username); 

}
