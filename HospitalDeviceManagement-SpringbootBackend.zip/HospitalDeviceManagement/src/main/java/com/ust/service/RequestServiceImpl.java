package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Employee;
import com.ust.model.status;
import com.ust.repository.RequestRepo;


@Service
public class RequestServiceImpl implements RequestService{

	@Autowired 
 	private RequestRepo repo; 
	
	
	
	@Override
	public boolean isPresent(int id) {
	
		return repo.existsById(id);
	}

	@Override
	public void updateRequest(status s) {
		// TODO Auto-generated method stub
		repo.save(s);
	}
	
	
	@Override
	public Integer addrequst(status e) {
		repo.save(e);
		return e.getRid();
	}
	
	@Override
	public List<status> listAllrecords() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	
	@Override
	public List<status> listAllrecordsbyfinance() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	
	@Override
	public Optional<status> getRequestById(int id) {
//		edao.findById(id);
		return repo.findById(id);
	}

	@Override
	public Optional<status> getRequestByIdfinance(int id) {
//		edao.findById(id);
		return repo.findById(id);
	}

	@Override
	public void updateStudentbyfinance(status s) {
		// TODO Auto-generated method stub
		repo.save(s);
	}
	@Override
	public void deletereq(Integer id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
		
	}

	@Override
	public List <status> findByfid1(String fid) {
		return repo.findByfid(fid);
	}


}
