package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Device;
import com.ust.repository.DeviceRepo;

@Service
public class DeviceServiceImpl implements DeviceService{

	@Autowired
	DeviceRepo repo;

	@Override
	public void updateDevices(Device e) {
		repo.save(e);
	}

	@Override
	public boolean isPresent(int id) {
		return repo.existsById(id);
	}

	@Override
	public Optional<Device> getDevicesById(int id) {
		return repo.findById(id); 
	}

	@Override
	public Integer addDevices(Device e) {
		return repo.save(e).getDid(); 
	}

	@Override
	public void deleteById(int id) {
		repo.deleteById(id); 
	}

	@Override
	public List<Device> listAllrecords() {
		return repo.findAll(); 
	}
	

	
}
