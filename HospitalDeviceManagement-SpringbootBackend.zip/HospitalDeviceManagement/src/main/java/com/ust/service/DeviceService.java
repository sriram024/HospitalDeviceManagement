package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.Device;


public interface DeviceService {
	
	public void updateDevices(Device e);
	public boolean isPresent(int id);
	public Optional<Device> getDevicesById(int id);
	public Integer addDevices(Device e);
	public void deleteById(int id);
	public List<Device> listAllrecords();

}
