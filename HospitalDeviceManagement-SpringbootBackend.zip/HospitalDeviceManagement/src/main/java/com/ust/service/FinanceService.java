package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.Finance;

public interface FinanceService {

	public Integer saveFinance(Finance s);  	
	public List<Finance> getAllFinance();  	
	public Optional<Finance> getOneFinance(Integer id);  
	public boolean isExist(Integer id);  	
	public void deleteFinance(Integer id);
	
	//login
	public Optional<Finance> searchusera(Integer username); 


}


