package com.ust.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.model.Device;

public interface DeviceRepo extends JpaRepository<Device,Integer>{

}




