package com.ust.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.model.Doctor;




 
public interface DoctorRepo extends JpaRepository<Doctor,Integer> 
{ 
 
}
